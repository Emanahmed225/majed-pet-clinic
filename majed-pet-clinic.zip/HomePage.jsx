
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-500 to-lime-400 p-6">
      <div className="max-w-6xl mx-auto text-center py-10">
        <h1 className="text-4xl md:text-6xl font-bold text-white drop-shadow-lg">
          Majed Pet Clinic
        </h1>
        <p className="mt-4 text-xl text-white">
          كل ما يحتاجه حيوانك الأليف – في مكان واحد!
        </p>
      </div>

      <div className="grid md:grid-cols-4 gap-6">
        {[
          "تخفيضات",
          "قطط",
          "كلاب",
          "طيور",
          "حيوانات صغيرة",
          "ماركات",
          "عروض",
          "وصل حديثاً",
        ].map((section) => (
          <Card key={section} className="hover:scale-105 transition-all duration-300">
            <CardContent className="p-4 text-center">
              <h2 className="text-2xl font-semibold text-purple-900">{section}</h2>
              <p className="text-sm text-gray-600 mt-2">Placeholder لمنتجات القسم</p>
              <Button className="mt-4 bg-purple-600 hover:bg-purple-700 text-white">
                تصفح القسم
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
